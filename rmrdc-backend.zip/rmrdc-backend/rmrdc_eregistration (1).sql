-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2024 at 11:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rmrdc_eregistration`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_certified`
--

CREATE TABLE `tbl_certified` (
  `id` int(11) NOT NULL,
  `email` varchar(225) NOT NULL,
  `company_name` varchar(225) NOT NULL,
  `amount_paid` int(11) NOT NULL DEFAULT 15000,
  `reference` varchar(100) NOT NULL,
  `isCertified` int(11) NOT NULL DEFAULT 0,
  `date_paid` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_certified`
--

INSERT INTO `tbl_certified` (`id`, `email`, `company_name`, `amount_paid`, `reference`, `isCertified`, `date_paid`) VALUES
(5, 'zaka@gmail.com', 'Nigeria agroallied ltd', 15000, '66df30dd7e522', 0, '2024-09-09 10:32:01');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company_details`
--

CREATE TABLE `tbl_company_details` (
  `email` varchar(225) NOT NULL,
  `company_name` varchar(225) NOT NULL,
  `ceo_name` varchar(150) NOT NULL,
  `office_address` varchar(225) NOT NULL,
  `state` varchar(60) NOT NULL,
  `lga` varchar(60) NOT NULL,
  `office_email` varchar(225) NOT NULL,
  `office_phone` varchar(100) NOT NULL,
  `factory_address` varchar(225) NOT NULL,
  `factory_state` varchar(60) NOT NULL,
  `factory_lga` varchar(60) NOT NULL,
  `rc_number` varchar(15) NOT NULL,
  `year_incorporation` date DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_company_details`
--

INSERT INTO `tbl_company_details` (`email`, `company_name`, `ceo_name`, `office_address`, `state`, `lga`, `office_email`, `office_phone`, `factory_address`, `factory_state`, `factory_lga`, `rc_number`, `year_incorporation`, `id`) VALUES
('eternalb123@gmail.com', 'ZIB Technology', 'buhari', 'abuja', 'FCT Abuja', 'Abaji', 'zibtechnology9@gmail.com', '23456', 'abuja', 'FCT Abuja', 'Gwagwalada', '234567', '2024-09-19', 1),
('zaka@gmail.com', 'Nigeria agroallied ltd', 'Abu', 'Musa', 'Cross River', 'Obubra', 'zaka@gmail.com', '09061609877', 'tafa local governemt', 'Ebonyi', 'Ivo', '33224424', '2024-09-25', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_corporate_overview`
--

CREATE TABLE `tbl_corporate_overview` (
  `id` int(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `company_type` varchar(225) NOT NULL,
  `company_owner` varchar(150) NOT NULL,
  `owner_gender` varchar(10) NOT NULL,
  `employee_number` varchar(100) NOT NULL,
  `project_turnover` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_corporate_overview`
--

INSERT INTO `tbl_corporate_overview` (`id`, `email`, `company_type`, `company_owner`, `owner_gender`, `employee_number`, `project_turnover`) VALUES
(2, 'eternalb123@gmail.com', 'Limited Liability Company', 'Sole Proprietorship', 'Male', '11 - 20', '500,000 - 1,000,000'),
(3, 'zaka@gmail.com', 'Limited Liability Company', 'Sole Proprietorship', 'Male', '2 - 10', '500,000 - 1,000,000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_directors`
--

CREATE TABLE `tbl_directors` (
  `id` int(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `director_name` varchar(150) NOT NULL,
  `director_address` varchar(225) NOT NULL,
  `director_email` varchar(150) NOT NULL,
  `director_phone` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_directors`
--

INSERT INTO `tbl_directors` (`id`, `email`, `director_name`, `director_address`, `director_email`, `director_phone`) VALUES
(1, 'eternalb123@gmail.com', 'director 1', 'director1 address', 'director1 email', 'director1 phone nunber'),
(2, 'eternalb123@gmail.com', 'director2 ', 'director2 address', 'director2 email', 'director2 phone'),
(3, 'eternalb123@gmail.com', 'director3', 'director3 address', 'director3 email', 'director3 phone'),
(4, 'zaka@gmail.com', 'ali', 'musa', 'chuoch@gmail.com', 'chukwu'),
(5, 'zaka@gmail.com', 'Isa', 'Ali', 'Enoch@gmail.com', 'David'),
(6, 'zaka@gmail.com', 'Eliot', 'Idriees', 'za@gmail.com', '098080808');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_lga`
--

CREATE TABLE `tbl_lga` (
  `id` int(11) NOT NULL,
  `lgaName` varchar(50) NOT NULL,
  `stateId` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_lga`
--

INSERT INTO `tbl_lga` (`id`, `lgaName`, `stateId`) VALUES
(1, 'Aba North', 1),
(2, 'Aba South', 1),
(3, 'Aba Arochukwu', 1),
(4, 'Bende', 1),
(5, 'Isiala Ngwa South', 1),
(6, 'Ikwuano', 1),
(8, 'Isiala Ngwa North', 1),
(9, 'Isukwuato', 1),
(10, 'Ukwa West', 1),
(11, 'Ukwa East', 1),
(12, 'Umuahia', 1),
(13, 'Umuahia South', 1),
(14, 'Demsa', 2),
(15, 'Fufore', 2),
(16, 'Gamye', 2),
(17, 'Girei', 2),
(18, 'Gombi', 2),
(19, 'Jada', 2),
(20, 'Yola North', 2),
(21, 'Lamurde', 2),
(22, 'Madagali', 2),
(23, 'Maiha', 2),
(24, 'Mayo-Belwa', 2),
(25, 'Michika', 2),
(26, 'Mubi South', 2),
(27, 'Numna', 2),
(28, 'Shelleng', 2),
(29, 'Song', 2),
(30, 'Toungo', 2),
(31, 'Jimeta', 2),
(32, 'Yola South', 2),
(33, 'Hung', 2),
(34, 'Aguata', 4),
(35, 'Anambra', 4),
(36, 'Anambra West', 4),
(37, 'Anaocha', 4),
(38, 'Awka South', 4),
(39, 'Awka North', 4),
(40, 'Ogbaru', 4),
(41, 'Onitsha South', 4),
(42, 'Onitsha North', 4),
(43, 'Orumba North', 4),
(44, 'Orumba South', 4),
(45, 'Oyi', 4),
(46, 'Abak', 3),
(47, 'Eastern Obolo', 3),
(48, 'Eket', 3),
(49, 'Essien Udim', 3),
(50, 'Etimekpo', 3),
(51, 'Etinan', 3),
(52, 'Ibeno', 3),
(53, 'Ibesikpo Asutan', 3),
(54, 'Ibiono Ibom', 3),
(55, 'Ika', 3),
(56, 'Ikono', 3),
(57, 'Ikot Abasi', 3),
(58, 'Ikot Ekpene', 3),
(59, 'Ini', 3),
(60, 'Itu', 3),
(61, 'Mbo', 3),
(62, 'Mkpat Enin', 3),
(63, 'Nsit Ibom', 3),
(64, 'Nsit Ubium', 3),
(65, 'Obot Akara', 3),
(66, 'Okobo', 3),
(67, 'Onna', 3),
(68, 'Orukanam', 3),
(69, 'Oron', 3),
(70, 'Udung Uko', 3),
(71, 'Ukanafun', 3),
(72, 'Esit Eket', 3),
(73, 'Uruan', 3),
(74, 'Urue Offoung', 3),
(75, 'Oruko Ete', 3),
(76, 'Uyo', 3),
(77, 'Alkaleri', 5),
(78, 'Bauchi', 5),
(79, 'Bogoro', 5),
(80, 'Darazo', 5),
(81, 'Dass', 5),
(82, 'Gamawa', 5),
(83, 'Ganjuwa', 5),
(84, 'Giade', 5),
(85, 'Jamaare', 5),
(86, 'Katagum', 5),
(87, 'Kirfi', 5),
(88, 'Misau', 5),
(89, 'Ningi', 5),
(90, 'Hira', 5),
(91, 'Tafawa Balewa', 5),
(92, 'Itas gadau', 5),
(93, 'Toro', 5),
(94, 'Warji', 5),
(95, 'Zaki', 5),
(96, 'Dambam', 5),
(97, 'Brass', 6),
(98, 'Ekeremor', 6),
(99, 'Kolok/Opokuma', 6),
(100, 'Nembe', 6),
(101, 'Ogbia', 6),
(102, 'Sagbama', 6),
(103, 'Southern Ijaw', 6),
(104, 'Yenagoa', 6),
(105, 'Membe', 6),
(106, 'Ador', 7),
(107, 'Agatu', 7),
(108, 'Apa', 7),
(109, 'Buruku', 7),
(110, 'Gboko', 7),
(111, 'Guma', 7),
(112, 'Gwer East', 7),
(113, 'Gwer West', 7),
(114, 'Katsina-ala', 7),
(115, 'Konshisha', 7),
(116, 'Kwande', 7),
(117, 'Logo', 7),
(118, 'Makurdi', 7),
(119, 'Obi', 7),
(120, 'Ogbadibo', 7),
(121, 'Ohimini', 7),
(122, 'Oju', 7),
(123, 'Okpokwu', 7),
(124, 'Oturkpo', 7),
(125, 'Tarka', 7),
(126, 'Ukum', 7),
(127, 'Vandekya', 7),
(128, 'Abadan', 8),
(129, 'Askira/Uba', 8),
(130, 'Bama', 8),
(131, 'Bayo', 8),
(132, 'Biu', 8),
(133, 'Chibok', 8),
(134, 'Damboa', 8),
(135, 'Dikwagubio', 8),
(136, 'Guzamala', 8),
(137, 'Gwoza', 8),
(138, 'Hawul', 8),
(139, 'Jere', 8),
(140, 'Kaga', 8),
(141, 'Kalka/Balge', 8),
(142, 'Konduga', 8),
(143, 'Kukawa', 8),
(144, 'Kwaya-ku', 8),
(145, 'Mafa', 8),
(146, 'Magumeri', 8),
(147, 'Maiduguri', 8),
(148, 'Marte', 8),
(149, 'Mobbar', 8),
(150, 'Monguno', 8),
(151, 'Ngala', 8),
(152, 'Nganzai', 8),
(153, 'Shani', 8),
(154, 'Abia', 9),
(155, 'Akampa', 9),
(156, 'Akpabuyo', 9),
(157, 'Bakassi', 9),
(158, 'Bekwara', 9),
(159, 'Biase', 9),
(160, 'Boki', 9),
(161, 'Calabar South', 9),
(162, 'Etung', 9),
(163, 'Ikom', 9),
(164, 'Obanliku', 9),
(165, 'Obubra', 9),
(166, 'Obudu', 9),
(167, 'Odukpani', 9),
(168, 'Ogoja', 9),
(169, 'Ugep North', 9),
(170, 'Yala', 9),
(171, 'Yarkur', 9),
(172, 'Aniocha South', 10),
(173, 'Anioha', 10),
(174, 'Bomadi', 10),
(175, 'Burutu', 10),
(176, 'Ethiope West', 10),
(177, 'Ethiope East', 10),
(178, 'Ika South', 10),
(179, 'Ika North East', 10),
(180, 'Isoko South', 10),
(181, 'Isoko North', 10),
(182, 'Ndokwa East', 10),
(183, 'Ndokwa West', 10),
(184, 'Okpe', 10),
(185, 'Oshimili North', 10),
(186, 'Oshimili South', 10),
(187, 'Patani', 10),
(188, 'Sapele', 10),
(189, 'Udu', 10),
(190, 'Ughelli South', 10),
(191, 'Ughelli North', 10),
(192, 'Ukwuani', 10),
(193, 'Uviwie', 10),
(194, 'Warri North', 10),
(195, 'Warri Central', 10),
(196, 'Warri South', 10),
(197, 'Abakaliki', 11),
(198, 'Afikpo South', 11),
(199, 'Afikpo North', 11),
(200, 'Ebonyi', 11),
(201, 'Ezza', 11),
(202, 'Ezza South', 11),
(203, 'Ikwo', 11),
(204, 'Ishielu', 11),
(205, 'Ivo', 11),
(206, 'Ohaozara', 11),
(207, 'Ohaukwu', 11),
(208, 'Onicha', 11),
(209, 'Izzi', 11),
(210, 'Akoko-Edo', 12),
(211, 'Egor', 12),
(212, 'Essann East', 12),
(213, 'Esan South East', 12),
(214, 'Esan Central', 12),
(215, 'Esan West', 12),
(216, 'Etsako Central', 12),
(217, 'Etsako East', 12),
(218, 'Etsako', 12),
(219, 'Orhionwon', 12),
(220, 'Ivia South West', 12),
(221, 'Ivia North', 12),
(222, 'Owan West', 12),
(223, 'Owan South', 12),
(224, 'Uhunwonde', 12),
(225, 'Ado Ekiti', 13),
(226, 'Effon Alaiye', 13),
(227, 'Ekiti South West', 13),
(228, 'Ekiti West', 13),
(229, 'Ekiti East', 13),
(230, 'Emure/Ise', 13),
(231, 'Orun', 13),
(232, 'Ido', 13),
(233, 'Osi', 13),
(234, 'Ijero', 13),
(235, 'Ikere', 13),
(236, 'Ikole', 13),
(237, 'Ilejemeje', 13),
(238, 'Irepodun', 13),
(239, 'Ise/Orun', 13),
(240, 'Moba', 13),
(241, 'Oye', 13),
(242, 'Aiyekire', 13),
(243, 'Awgu', 14),
(244, 'Aninri', 14),
(245, 'Enugu East', 14),
(246, 'Enugu South', 14),
(247, 'Enugu North', 14),
(248, 'Ezeagu', 14),
(249, 'Igbo Eze North', 14),
(250, 'Igbi Etiti', 14),
(251, 'Nsukka', 14),
(252, 'Oji River', 14),
(253, 'Undenu', 14),
(254, 'Uzo Uwani', 14),
(255, 'Udi', 14),
(256, 'Akko', 15),
(257, 'Balanga', 15),
(258, 'Billiri', 15),
(259, 'Dukku', 15),
(260, 'Dunakaye', 15),
(261, 'Gombe', 15),
(262, 'Kaltungo', 15),
(263, 'Kwami', 15),
(264, 'Nafada/Bajoga', 15),
(265, 'Shomgom', 15),
(266, 'Yamaltu/Deba', 15),
(267, 'Aboh-mbaise', 16),
(268, 'Ahiazu-mbaino', 16),
(269, 'Ehime-mbaino', 16),
(270, 'Ezinhite Ideato North', 16),
(271, 'Ideato South', 16),
(272, 'Ihitte/Uboma', 16),
(273, 'Ikeduru', 16),
(274, 'Isiala', 16),
(275, 'Isu', 16),
(276, 'Mbaitoli', 16),
(277, 'Ngor Okpala', 16),
(278, 'Njaba', 16),
(279, 'Nwangele', 16),
(280, 'Nkwere', 16),
(281, 'Obowo', 16),
(282, 'Aguta', 16),
(283, 'Ohaji Egbema', 16),
(284, 'Okigwe', 16),
(285, 'Onuimo', 16),
(286, 'Orlu', 16),
(287, 'Orsu', 16),
(288, 'Oru West', 16),
(289, 'Oru', 16),
(290, 'Owerri', 16),
(291, 'Owerri North', 16),
(292, 'Owerri South', 16),
(293, 'Auyo', 17),
(294, 'Babura', 17),
(295, 'Birnin-Kudu', 17),
(296, 'Birniwa', 17),
(297, 'Buji', 17),
(298, 'Dutse', 17),
(299, 'Garki', 17),
(300, 'Gagarawa', 17),
(301, 'Gumel', 17),
(302, 'Guri', 17),
(303, 'Gwaram', 17),
(304, 'Gwiwa', 17),
(305, 'Hadeji', 17),
(306, 'Jahun', 17),
(307, 'Kafin-Hausa', 17),
(308, 'Kaugama', 17),
(309, 'Kazaure', 17),
(310, 'Kirikisamma', 17),
(311, 'Birnin-magaji', 17),
(312, 'Maigatari', 17),
(313, 'Malamaduri', 17),
(314, 'Miga', 17),
(315, 'Ringim', 17),
(316, 'Roni', 17),
(317, 'Sule Tankarka', 17),
(318, 'Taura', 17),
(319, 'Yankwasi', 17),
(320, 'Birnin Gwari', 18),
(321, 'Chukun', 18),
(322, 'Giwa', 18),
(323, 'Kajuru', 18),
(324, 'Igabi', 18),
(325, 'Ikara', 18),
(326, 'Jaba', 18),
(327, 'jemaa', 18),
(328, 'Kachia', 18),
(329, 'Kaduna North', 18),
(330, 'Kaduna South', 18),
(331, 'Kagarok', 18),
(332, 'Kauru', 18),
(333, 'Kabau', 18),
(334, 'Kudan', 18),
(335, 'Kere', 18),
(336, 'Makarfi', 18),
(337, 'Sabongari', 18),
(338, 'Sanga', 18),
(339, 'Soba', 18),
(340, 'Zangon-Kataf', 18),
(341, 'Zaria', 18),
(342, 'Abaji', 37),
(343, 'Abuja Municipal', 37),
(344, 'Bwari', 37),
(345, 'Gwagwalada', 37),
(346, 'Kuje', 37),
(347, 'Kwali', 37),
(348, 'Ajigi', 19),
(349, 'Albasu', 19),
(350, 'Bagwai', 19),
(351, 'Bebeji', 19),
(352, 'Bichi', 19),
(353, 'Bunkure', 19),
(354, 'Dala', 19),
(355, 'Dambatta', 19),
(356, 'Dawakin Kudu', 19),
(357, 'Dawakin tofa', 19),
(358, 'Doguwa', 19),
(359, 'Fagge', 19),
(360, 'Gabasawa', 19),
(361, 'Garko', 19),
(362, 'Garun Mallam', 19),
(363, 'Gaya', 19),
(364, 'Gezawa', 19),
(365, 'Gwale', 19),
(366, 'Gwarzo', 19),
(367, 'Kano', 19),
(368, 'Karay', 19),
(369, 'Kibiya', 19),
(370, 'Kiru', 19),
(371, 'Kumbtso', 19),
(372, 'Kunch', 19),
(373, 'Kura', 19),
(374, 'Maidobi', 19),
(375, 'Makoda', 19),
(376, 'Minjibir', 19),
(377, 'Nassarawa', 19),
(378, 'Rano', 19),
(379, 'Rimin Gado', 19),
(380, 'Rogo', 19),
(381, 'Shanono', 19),
(382, 'Sunmaila', 19),
(383, 'Takai', 19),
(384, 'Tarauni', 19),
(385, 'Tofa', 19),
(386, 'Tsanyawa', 19),
(387, 'Tudunwada', 19),
(388, 'Ungogo', 19),
(389, 'Warawa', 19),
(390, 'Wudil', 19),
(391, 'Bakori', 20),
(392, 'Batagarawa', 20),
(393, 'Batsari', 20),
(394, 'Baure', 20),
(395, 'Bindawa', 20),
(396, 'Charanchi', 20),
(397, 'Dan-Musa', 20),
(398, 'Dandume', 20),
(399, 'Danja', 20),
(400, 'Daura', 20),
(401, 'Dutsi', 20),
(402, 'Dutsin ma', 20),
(403, 'Faskar', 20),
(404, 'Funtua', 20),
(405, 'Ingawa', 20),
(406, 'Jibiya', 20),
(407, 'Kafur', 20),
(408, 'Kaita', 20),
(409, 'Kankara', 20),
(410, 'Kankiya', 20),
(411, 'Katsina', 20),
(412, 'Furfi', 20),
(413, 'Kusada', 20),
(414, 'Mai aduwa', 20),
(415, 'Malumfashi', 20),
(416, 'Mani', 20),
(417, 'Mash', 20),
(418, 'Matazu', 20),
(419, 'Musawa', 20),
(420, 'Rimi', 20),
(421, 'Sabuwa', 20),
(422, 'Safana', 20),
(423, 'Sandamu', 20),
(424, 'Zango', 20),
(425, 'Aliero', 21),
(426, 'Arewa Dandi', 21),
(427, 'Argungu', 21),
(428, 'Augie', 21),
(429, 'Bagudo', 21),
(430, 'Birnin Kebbi', 21),
(431, 'Bunza', 21),
(432, 'Dandi', 21),
(433, 'Danko', 21),
(434, 'Fakai', 21),
(435, 'Gwandu', 21),
(436, 'Jeda', 21),
(437, 'Kalgo', 21),
(438, 'Koko-besse', 21),
(439, 'Maiyaama', 21),
(440, 'Ngaski', 21),
(441, 'Sakaba', 21),
(442, 'Shanga', 21),
(443, 'Suru', 21),
(444, 'Wasugu', 21),
(445, 'Yauri', 21),
(446, 'Zuru', 21),
(447, 'Adavi', 22),
(448, 'Ajaokuta', 22),
(449, 'Ankpa', 22),
(450, 'Bassa', 22),
(451, 'Dekina', 22),
(452, 'Yagba East', 22),
(453, 'Ibaji', 22),
(454, 'Idah', 22),
(455, 'Igalamela', 22),
(456, 'Ijumu', 22),
(457, 'Kabba bunu', 22),
(458, 'Kogi', 22),
(459, 'Mopa muro', 22),
(460, 'Ofu', 22),
(461, 'Ogori Magongo', 22),
(462, 'Okehi', 22),
(463, 'Okene', 22),
(464, 'Olamaboro', 22),
(465, 'Omala', 22),
(466, 'Yagba West', 22),
(467, 'Asa', 23),
(468, 'Baruten', 23),
(469, 'Ede', 23),
(470, 'Ekiti', 23),
(471, 'Ifelodun', 23),
(472, 'Ilorin South', 23),
(473, 'Ilorin West', 23),
(474, 'Ilorin East', 23),
(475, 'Irepodun', 23),
(476, 'Isin', 23),
(477, 'Kaiama', 23),
(478, 'Moro', 23),
(479, 'Offa', 23),
(480, 'Oke ero', 23),
(481, 'Oyun', 23),
(482, 'Pategi', 23),
(483, 'Agege', 24),
(484, 'Alimosho Ifelodun', 24),
(485, 'Alimosho', 24),
(486, 'Amuwo-Odofin', 24),
(487, 'Apapa', 24),
(488, 'Badagry', 24),
(489, 'Epe', 24),
(490, 'Eti-Osa', 24),
(491, 'Ibeju-Lekki', 24),
(492, 'Ifako/Ijaye', 24),
(493, 'Ikeja', 24),
(494, 'Ikorodu', 24),
(495, 'Kosofe', 24),
(496, 'Lagos Island', 24),
(497, 'Lagos Mainland', 24),
(498, 'Mushin', 24),
(499, 'Ojo', 24),
(500, 'Oshodi-Isolo', 24),
(501, 'Shomolu', 24),
(502, 'Surulere', 24),
(503, 'Akwanga', 25),
(504, 'Awe', 25),
(505, 'Doma', 25),
(506, 'Karu', 25),
(507, 'Keana', 25),
(508, 'Keffi', 25),
(509, 'Kokona', 25),
(510, 'Lafia', 25),
(511, 'Nasarawa', 25),
(512, 'Nasarawa/Eggon', 25),
(513, 'Obi', 25),
(514, 'Toto', 25),
(515, 'Wamba', 25),
(516, 'Agaie', 26),
(517, 'Agwara', 26),
(518, 'Bida', 26),
(519, 'Borgu', 26),
(520, 'Bosso', 26),
(521, 'Chanchanga', 26),
(522, 'Edati', 26),
(523, 'Gbako', 26),
(524, 'Gurara', 26),
(525, 'Kitcha', 26),
(526, 'Kontagora', 26),
(527, 'Lapai', 26),
(528, 'Lavun', 26),
(529, 'Magama', 26),
(530, 'Mariga', 26),
(531, 'Mokwa', 26),
(532, 'Moshegu', 26),
(533, 'Muya', 26),
(534, 'Paiko', 26),
(535, 'Rafi', 26),
(536, 'Shiroro', 26),
(537, 'Suleja', 26),
(538, 'Tawa-Wushishi', 26),
(539, 'Abeokuta South', 27),
(540, 'Abeokuta North', 27),
(541, 'Ado-odo/otta', 27),
(542, 'Agbado South', 27),
(543, 'Agbado North', 27),
(544, 'Ewekoro', 27),
(545, 'Idarapo', 27),
(546, 'Ifo', 27),
(547, 'Ijebu East', 27),
(548, 'Ijebu North', 27),
(549, 'Ikenne', 27),
(550, 'Ilugun Alaro', 27),
(551, 'Imeko Afon', 27),
(552, 'Ipokia', 27),
(553, 'Obafemi/owode', 27),
(554, 'Odeda', 27),
(555, 'Odogbolu', 27),
(556, 'Ogun Waterside', 27),
(557, 'Sagamu', 27),
(558, 'Akoko North', 28),
(559, 'Akoko North East', 28),
(560, 'Akoko South East', 28),
(561, 'Akoko South', 28),
(562, 'Akure North', 28),
(563, 'Akure', 28),
(564, 'Idanre', 28),
(565, 'Ifedore', 28),
(566, 'Ese Odo', 28),
(567, 'Ilaje', 28),
(568, 'Ilaje oke-igbo', 28),
(569, 'Irele', 28),
(570, 'Odigbo', 28),
(571, 'Okitipupa', 28),
(572, 'Ondo', 28),
(573, 'Ondo East', 28),
(574, 'Ose', 28),
(575, 'Owo', 28),
(576, 'Atakumosa West', 29),
(577, 'Atakumosa East', 29),
(578, 'Ayeda-ade', 29),
(579, 'Ayedire', 29),
(580, 'Bolawaduro', 29),
(581, 'Boripe', 29),
(582, 'Ede', 29),
(583, 'Ede North', 29),
(584, 'Egbedore', 29),
(585, 'Ejigbo', 29),
(586, 'Ife North', 29),
(587, 'Ife Central', 29),
(588, 'Ife South', 29),
(589, 'Ife East', 29),
(590, 'Ifedayo', 29),
(591, 'Ifelodun', 29),
(592, 'Ilesha West', 29),
(593, 'Ila-Orangun', 29),
(594, 'Ilesah East', 29),
(595, 'Irepodun', 29),
(596, 'Irewole', 29),
(597, 'Isokan', 29),
(598, 'Iwo', 29),
(599, 'Obokun', 29),
(600, 'Odo-otin', 29),
(601, 'Ola oluwa', 29),
(602, 'Olorunda', 29),
(603, 'Oriade', 29),
(604, 'Orolu', 29),
(605, 'Osogbo', 29),
(606, 'Afijio', 30),
(607, 'Akinyele', 30),
(608, 'Attba', 30),
(609, 'Atigbo', 30),
(610, 'Egbeda', 30),
(611, 'Ibadan', 30),
(612, 'Ibadan North East', 30),
(613, 'Ibadan Central', 30),
(614, 'Ibadan South East', 30),
(615, 'Ibadan West South', 30),
(616, 'Ibarapa East', 30),
(617, 'Ibarapa North', 30),
(618, 'Ido', 30),
(619, 'Ifedapo', 30),
(620, 'Ifeloju', 30),
(621, 'Irepo', 30),
(622, 'Iseyin', 30),
(623, 'Itesiwaju', 30),
(624, 'Iwajowa', 30),
(625, 'Iwajowa Olorunshogo', 30),
(626, 'Kajola', 30),
(627, 'Lagelu', 30),
(628, 'Ogbomosho North', 30),
(629, 'Ogbomosho South', 30),
(630, 'Ogo Oluwa', 30),
(631, 'Oluyole', 30),
(632, 'Ona ara', 30),
(633, 'Ore lope', 30),
(634, 'Orire', 30),
(635, 'Oyo East', 30),
(636, 'Oyo West', 30),
(637, 'Saki East', 30),
(638, 'Saki West', 30),
(639, 'Surulere', 30),
(640, 'Barkin/ladi', 31),
(641, 'Bassa', 31),
(642, 'Bokkos', 31),
(643, 'Jos North', 31),
(644, 'Jos East', 31),
(645, 'Jos South', 31),
(646, 'Kanam', 31),
(647, 'Kiyom', 31),
(648, 'Langtang North', 31),
(649, 'Langtang South', 31),
(650, 'Mangu', 31),
(651, 'Mikang', 31),
(652, 'Pankshin', 31),
(653, 'Quampan', 31),
(654, 'Shendam', 31),
(655, 'Wase', 31),
(656, 'Abua/Odial', 32),
(657, 'Ahoada West', 32),
(658, 'Akuku toru', 32),
(659, 'Andoni', 32),
(660, 'Asari toru', 32),
(661, 'Bonny', 32),
(662, 'Degema', 32),
(663, 'Eleme', 32),
(664, 'Emohua', 32),
(665, 'Etche', 32),
(666, 'Gokana', 32),
(667, 'Ikwerre', 32),
(668, 'Oyigbo', 32),
(669, 'Khana', 32),
(670, 'Obio/Akpor', 32),
(671, 'Ogba East/Edoni', 32),
(672, 'Ogu/Bolo', 32),
(673, 'Okrika', 32),
(674, 'Omumma', 32),
(675, 'Opobo/Nkoro', 32),
(676, 'Portharcourt', 32),
(677, 'Tai', 32),
(678, 'Binji', 33),
(679, 'Bodinga', 33),
(680, 'Dange/Shuni', 33),
(681, 'Gada', 33),
(682, 'Goronyo', 33),
(683, 'Gudu', 33),
(684, 'Gwadabawa', 33),
(685, 'Illela', 33),
(686, 'Kebbe', 33),
(687, 'Kware', 33),
(688, 'Rabah', 33),
(689, 'Sabon-Birni', 33),
(690, 'Shagari', 33),
(691, 'Silame', 33),
(692, 'Sokoto South', 33),
(693, 'Sokoto North', 33),
(694, 'Tambuwal', 33),
(695, 'Tangaza', 33),
(696, 'Tureta', 33),
(697, 'Wamakko', 33),
(698, 'Wurno', 33),
(699, 'Yabo', 33),
(700, 'Akdo-kola', 34),
(701, 'Bali', 34),
(702, 'Donga', 34),
(703, 'Gashaka', 34),
(704, 'Gassol', 34),
(705, 'Ibi', 34),
(706, 'Jalingo', 34),
(707, 'K/Lamido', 34),
(708, 'Kurmi', 34),
(709, 'Lan', 34),
(710, 'Sardauna', 34),
(711, 'Tarum', 34),
(712, 'Ussa', 34),
(713, 'Wukari', 34),
(714, 'Yorro', 34),
(715, 'Zing', 34),
(716, 'Borsari', 35),
(717, 'Damaturu', 35),
(718, 'Fika', 35),
(719, 'Fune', 35),
(720, 'Geidam', 35),
(721, 'Gogaram', 35),
(722, 'Gujba', 35),
(723, 'Gulani', 35),
(724, 'Jakusko', 35),
(725, 'Karasuwa', 35),
(726, 'Machina', 35),
(727, 'Nagere', 35),
(728, 'Nguru', 35),
(729, 'Potiskum', 35),
(730, 'Tarmua', 35),
(731, 'Yunusari', 35),
(732, 'Yusufari', 35),
(733, 'Gashua', 35),
(734, 'Anka', 36),
(735, 'Bukkuyum', 36),
(736, 'Dungudu', 36),
(737, 'Chafe', 36),
(738, 'Gummi', 36),
(739, 'Gusau', 36),
(740, 'Isa', 36),
(741, 'Kaura Namoda', 36),
(742, 'Mradun', 36),
(743, 'Maru', 36),
(744, 'Shinkafi', 36),
(745, 'Talata Mafara', 36),
(746, 'Zumi', 36);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_raw_material`
--

CREATE TABLE `tbl_raw_material` (
  `ID` int(10) NOT NULL,
  `raw_material_name` varchar(50) NOT NULL,
  `Sector_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_raw_material`
--

INSERT INTO `tbl_raw_material` (`ID`, `raw_material_name`, `Sector_ID`) VALUES
(1, 'Oil', 1),
(2, 'Natural Gas', 1),
(3, 'Coal', 1),
(4, 'Tin', 1),
(5, 'Iron Ore', 1),
(6, 'Limestone', 1),
(7, 'Nobium', 1),
(8, 'Lead', 1),
(9, 'Zinc', 1),
(10, 'Palm Oil', 2),
(11, 'Soya Beans', 2),
(12, 'Coffe', 2),
(13, 'Cocoa', 2),
(14, 'Sesame Oil', 4),
(15, 'Cinnamon', 4),
(16, 'Diamond Oil', 4),
(17, 'Bromclain', 4),
(18, 'Polyester', 5),
(19, 'Cotton', 5),
(20, 'Palm Kernel Oil', 3),
(21, 'Sunflower Oil', 3),
(22, 'Sweet Almond Oil', 3),
(23, 'Cellulose', 6),
(24, 'Salt', 6),
(25, 'Garlic', 7),
(26, 'Tumeric', 7),
(27, 'Pepper', 7),
(28, 'Scent Leave', 7),
(29, 'Granite', 8),
(30, 'Metal', 8),
(31, 'Wood', 8),
(32, 'Kerosene', 11),
(33, 'Natural Gas', 11),
(34, 'Tin', 11),
(35, 'Coal', 11),
(36, 'Citric Acid', 9),
(37, 'Maize Starch', 9);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_state`
--

CREATE TABLE `tbl_state` (
  `id` int(11) NOT NULL,
  `stateName` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_state`
--

INSERT INTO `tbl_state` (`id`, `stateName`) VALUES
(1, 'Abia'),
(2, 'Adamawa'),
(3, 'Akwa Ibom'),
(4, 'Anambra'),
(5, 'Bauchi'),
(6, 'Bayelsa'),
(7, 'Benue'),
(8, 'Borno'),
(9, 'Cross River'),
(10, 'Delta'),
(11, 'Ebonyi'),
(12, 'Edo'),
(13, 'Ekiti'),
(14, 'Enugu'),
(15, 'Gombe'),
(16, 'Imo'),
(17, 'Jigawa'),
(18, 'Kaduna'),
(19, 'Kano'),
(20, 'Katsina'),
(21, 'Kebbi'),
(22, 'Kogi'),
(23, 'Kwara'),
(24, 'Lagos'),
(25, 'Nasarawa'),
(26, 'Niger'),
(27, 'Ogun'),
(28, 'Ondo'),
(29, 'Osun'),
(30, 'Oyo'),
(31, 'Plateau'),
(32, 'Rivers'),
(33, 'Sokoto'),
(34, 'Taraba'),
(35, 'Yobe'),
(36, 'Zamfara'),
(37, 'FCT Abuja');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_trade_classification`
--

CREATE TABLE `tbl_trade_classification` (
  `id` int(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `trade_category` varchar(225) NOT NULL,
  `trade_sector` varchar(225) NOT NULL,
  `raw_materials` varchar(225) NOT NULL,
  `production_rate` varchar(150) DEFAULT NULL,
  `present_capacity` varchar(225) DEFAULT NULL,
  `warehouse_capacity` varchar(225) DEFAULT NULL,
  `local_percentage` varchar(150) NOT NULL,
  `import_percentage` varchar(225) NOT NULL,
  `contact_name` varchar(150) NOT NULL,
  `contact_position` varchar(150) NOT NULL,
  `contact_address` varchar(225) NOT NULL,
  `contact_email` varchar(150) NOT NULL,
  `contact_phone` varchar(100) NOT NULL,
  `trade_type` varchar(150) NOT NULL,
  `incorporation_cert` varchar(150) NOT NULL,
  `board_resolution_cert` varchar(150) NOT NULL,
  `memorandum_cert` varchar(150) NOT NULL,
  `directors_particulars_cert` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_trade_classification`
--

INSERT INTO `tbl_trade_classification` (`id`, `email`, `trade_category`, `trade_sector`, `raw_materials`, `production_rate`, `present_capacity`, `warehouse_capacity`, `local_percentage`, `import_percentage`, `contact_name`, `contact_position`, `contact_address`, `contact_email`, `contact_phone`, `trade_type`, `incorporation_cert`, `board_resolution_cert`, `memorandum_cert`, `directors_particulars_cert`) VALUES
(3, 'eternalb123@gmail.com', 'Exporters', 'Solid Minerals', 'Coal', '', '', '', '50', '50', 'Buhari Iliyasu', 'Marketer', 'Abuja', 'eternalb123@gmail.com', '08065763543', 'Limited Liability', 'inc_1725629692.jpg', 'board_1725629692.jpg', 'memo_1725629692.jpg', 'dir_1725629692.jpg'),
(4, 'zaka@gmail.com', 'Exporters', '9,Pharmaceutical', 'Citric Acid', '', '', '', '70', '85', 'Musa Idris', 'CEO', 'TAFA LGA', 'SASAD@GHAJKAK.COM', '0909890000', 'Limited Liability', 'inc_1725903049.xlsx', 'board_1725903049.xlsx', 'memo_1725903049.xlsx', 'dir_1725903049.xlsx');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_trade_sector`
--

CREATE TABLE `tbl_trade_sector` (
  `ID` int(10) NOT NULL,
  `Sector_Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_trade_sector`
--

INSERT INTO `tbl_trade_sector` (`ID`, `Sector_Name`) VALUES
(1, 'Solid Minerals'),
(2, 'Agricultural'),
(3, 'Cosmetics'),
(4, 'Herbal'),
(5, 'Textile'),
(6, 'Plastic and Rubber'),
(7, 'Spices'),
(8, 'Building and Electronical'),
(9, 'Pharmaceutical'),
(11, 'Petroleum');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `company_name` varchar(220) NOT NULL,
  `email` varchar(220) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `password` varchar(220) NOT NULL,
  `activation_token` varchar(220) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `company_name`, `email`, `phone`, `password`, `activation_token`) VALUES
(1, 'ZIB Technology', 'eternalb123@gmail.com', '08057601812', '1234', NULL),
(5, 'Sam Enterprise', 'samuelokereke55@gmail.com', '08167920916', '12345678', NULL),
(6, 'Nigeria agroallied ltd', 'zaka@gmail.com', '09101567890', '1234567890', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_certified`
--
ALTER TABLE `tbl_certified`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_company_details`
--
ALTER TABLE `tbl_company_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_corporate_overview`
--
ALTER TABLE `tbl_corporate_overview`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_directors`
--
ALTER TABLE `tbl_directors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_lga`
--
ALTER TABLE `tbl_lga`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_raw_material`
--
ALTER TABLE `tbl_raw_material`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_state`
--
ALTER TABLE `tbl_state`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_trade_classification`
--
ALTER TABLE `tbl_trade_classification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_trade_sector`
--
ALTER TABLE `tbl_trade_sector`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `company_name` (`company_name`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_certified`
--
ALTER TABLE `tbl_certified`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_company_details`
--
ALTER TABLE `tbl_company_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_corporate_overview`
--
ALTER TABLE `tbl_corporate_overview`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_directors`
--
ALTER TABLE `tbl_directors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_lga`
--
ALTER TABLE `tbl_lga`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=747;

--
-- AUTO_INCREMENT for table `tbl_raw_material`
--
ALTER TABLE `tbl_raw_material`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `tbl_state`
--
ALTER TABLE `tbl_state`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `tbl_trade_classification`
--
ALTER TABLE `tbl_trade_classification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_trade_sector`
--
ALTER TABLE `tbl_trade_sector`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
